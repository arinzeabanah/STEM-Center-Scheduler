"""Unit tests for the automated conflict detection engine.

Run with:  python -m pytest
"""

from datetime import datetime

from scheduler.conflict_detector import ConflictDetector


class FakeEvent:
    """Lightweight stand-in for the SQLAlchemy Event model."""

    def __init__(self, start, end, title="Existing booking"):
        self.start_time = start
        self.end_time = end
        self.title = title


def dt(hour, minute=0):
    return datetime(2026, 7, 7, hour, minute)


class TestOverlaps:
    def test_full_overlap(self):
        assert ConflictDetector.overlaps(dt(10), dt(12), dt(10), dt(12))

    def test_partial_overlap_start(self):
        assert ConflictDetector.overlaps(dt(9), dt(11), dt(10), dt(12))

    def test_partial_overlap_end(self):
        assert ConflictDetector.overlaps(dt(11), dt(13), dt(10), dt(12))

    def test_contained_within(self):
        assert ConflictDetector.overlaps(dt(10, 30), dt(11), dt(10), dt(12))

    def test_no_overlap(self):
        assert not ConflictDetector.overlaps(dt(8), dt(9), dt(10), dt(12))

    def test_back_to_back_is_allowed(self):
        # An event ending at 10:00 does NOT conflict with one starting at 10:00.
        assert not ConflictDetector.overlaps(dt(9), dt(10), dt(10), dt(11))


class TestFindConflicts:
    def test_returns_only_overlapping_events(self):
        existing = [
            FakeEvent(dt(9), dt(10), "Morning tutoring"),
            FakeEvent(dt(10, 30), dt(11, 30), "Study group"),
            FakeEvent(dt(14), dt(15), "Afternoon workshop"),
        ]
        conflicts = ConflictDetector.find_conflicts(dt(10), dt(11), existing)
        assert len(conflicts) == 1
        assert conflicts[0].title == "Study group"

    def test_no_conflicts_on_free_slot(self):
        existing = [FakeEvent(dt(9), dt(10))]
        assert ConflictDetector.find_conflicts(dt(12), dt(13), existing) == []


class TestSuggestAlternatives:
    def test_suggests_conflict_free_slots(self):
        existing = [FakeEvent(dt(10), dt(11))]
        suggestions = ConflictDetector.suggest_alternatives(
            dt(10), dt(11), existing
        )
        assert suggestions, "expected at least one suggestion"
        for start, end in suggestions:
            assert not ConflictDetector.find_conflicts(start, end, existing)

    def test_suggestions_keep_duration(self):
        existing = [FakeEvent(dt(10), dt(11))]
        requested_duration = dt(11, 30) - dt(10)
        suggestions = ConflictDetector.suggest_alternatives(
            dt(10), dt(11, 30), existing
        )
        for start, end in suggestions:
            assert end - start == requested_duration

    def test_respects_operating_hours(self):
        suggestions = ConflictDetector.suggest_alternatives(dt(9), dt(10), [])
        for start, end in suggestions:
            assert start.hour >= ConflictDetector.OPEN_HOUR
            assert end.hour <= ConflictDetector.CLOSE_HOUR
