"""
Email notifications for booking confirmations and cancellations.

Sends via SMTP when configured through environment variables; otherwise
logs the message so the app remains fully usable in development.
"""

import logging
import os
import smtplib
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)


class NotificationService:
    def __init__(self):
        self.host = os.getenv("SMTP_HOST", "")
        self.port = int(os.getenv("SMTP_PORT", "587"))
        self.user = os.getenv("SMTP_USER", "")
        self.password = os.getenv("SMTP_PASSWORD", "")
        self.from_email = os.getenv("FROM_EMAIL", "stemcenter@tsc.fl.edu")

    @property
    def enabled(self):
        return bool(self.host and self.user)

    def send_confirmation(self, event):
        subject = f"Booking confirmed: {event.title}"
        body = (
            f"Hi {event.organizer_name},\n\n"
            f"Your STEM Center booking is confirmed.\n\n"
            f"  Event: {event.title}\n"
            f"  Room:  {event.room.name}\n"
            f"  Start: {event.start_time:%A, %B %d, %Y at %I:%M %p}\n"
            f"  End:   {event.end_time:%I:%M %p}\n\n"
            f"Need to cancel? Visit the STEM Center scheduling portal.\n\n"
            f"— Tallahassee State College STEM Center"
        )
        self._send(event.organizer_email, subject, body)

    def send_cancellation(self, event):
        subject = f"Booking cancelled: {event.title}"
        body = (
            f"Hi {event.organizer_name},\n\n"
            f"Your booking \"{event.title}\" in {event.room.name} on "
            f"{event.start_time:%B %d, %Y at %I:%M %p} has been cancelled.\n\n"
            f"— Tallahassee State College STEM Center"
        )
        self._send(event.organizer_email, subject, body)

    def _send(self, to_email, subject, body):
        if not self.enabled:
            logger.info("[email disabled] To: %s | %s\n%s",
                        to_email, subject, body)
            return

        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = self.from_email
        msg["To"] = to_email

        try:
            with smtplib.SMTP(self.host, self.port) as server:
                server.starttls()
                server.login(self.user, self.password)
                server.send_message(msg)
            logger.info("Sent email to %s: %s", to_email, subject)
        except Exception:
            logger.exception("Failed to send email to %s", to_email)
