"""
STEM Center Scheduler — Tallahassee State College
=================================================
Web-based scheduling system for STEM Center staff. Automates event
scheduling and notifications via the Google Calendar API, with
automated conflict detection to reduce double-bookings.

Run locally:
    pip install -r requirements.txt
    python app.py
"""

from datetime import datetime

from flask import Flask, jsonify, render_template, request

from scheduler.calendar_service import CalendarService
from scheduler.conflict_detector import ConflictDetector
from scheduler.models import db, Event, Room
from scheduler.notifications import NotificationService

app = Flask(__name__)
app.config.from_object("config.Config")

db.init_app(app)
calendar_service = CalendarService()
notifier = NotificationService()

DEFAULT_ROOMS = [
    ("Tutoring Lab A", 24),
    ("Tutoring Lab B", 16),
    ("Computer Lab 114", 30),
    ("Study Room 201", 8),
    ("Study Room 202", 8),
    ("Conference Room", 12),
]


@app.before_request
def _init_db():
    """Create tables and seed rooms on first request."""
    if not getattr(app, "_db_initialized", False):
        with app.app_context():
            db.create_all()
            if Room.query.count() == 0:
                for name, capacity in DEFAULT_ROOMS:
                    db.session.add(Room(name=name, capacity=capacity))
                db.session.commit()
        app._db_initialized = True


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


# ---------------------------------------------------------------------------
# API — Rooms
# ---------------------------------------------------------------------------

@app.route("/api/rooms", methods=["GET"])
def list_rooms():
    rooms = Room.query.order_by(Room.name).all()
    return jsonify([r.to_dict() for r in rooms])


# ---------------------------------------------------------------------------
# API — Events
# ---------------------------------------------------------------------------

@app.route("/api/events", methods=["GET"])
def list_events():
    """List events, optionally filtered by ?date=YYYY-MM-DD or ?room_id=N."""
    query = Event.query

    date_str = request.args.get("date")
    if date_str:
        try:
            day = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            return jsonify({"error": "date must be YYYY-MM-DD"}), 400
        query = query.filter(db.func.date(Event.start_time) == day)

    room_id = request.args.get("room_id", type=int)
    if room_id:
        query = query.filter(Event.room_id == room_id)

    events = query.order_by(Event.start_time).all()
    return jsonify([e.to_dict() for e in events])


@app.route("/api/events", methods=["POST"])
def create_event():
    data = request.get_json(silent=True) or {}
    error = _validate_event_payload(data)
    if error:
        return jsonify({"error": error}), 400

    start = datetime.fromisoformat(data["start_time"])
    end = datetime.fromisoformat(data["end_time"])

    # --- Automated conflict detection -------------------------------------
    existing = Event.query.filter(Event.room_id == data["room_id"]).all()
    conflicts = ConflictDetector.find_conflicts(start, end, existing)
    if conflicts and not data.get("force"):
        return (
            jsonify(
                {
                    "error": "Scheduling conflict detected",
                    "conflicts": [c.to_dict() for c in conflicts],
                }
            ),
            409,
        )

    event = Event(
        title=data["title"].strip(),
        description=data.get("description", "").strip(),
        organizer_name=data["organizer_name"].strip(),
        organizer_email=data["organizer_email"].strip().lower(),
        room_id=data["room_id"],
        start_time=start,
        end_time=end,
    )
    db.session.add(event)
    db.session.commit()

    # --- Google Calendar sync (no-op if credentials aren't configured) ----
    google_id = calendar_service.create_event(event)
    if google_id:
        event.google_event_id = google_id
        db.session.commit()

    # --- Notification ------------------------------------------------------
    notifier.send_confirmation(event)

    return jsonify(event.to_dict()), 201


@app.route("/api/events/<int:event_id>", methods=["DELETE"])
def delete_event(event_id):
    event = Event.query.get_or_404(event_id)
    calendar_service.delete_event(event)
    notifier.send_cancellation(event)
    db.session.delete(event)
    db.session.commit()
    return jsonify({"status": "deleted"})


@app.route("/api/check-conflicts", methods=["POST"])
def check_conflicts():
    """Live conflict check used by the form before submission."""
    data = request.get_json(silent=True) or {}
    try:
        start = datetime.fromisoformat(data["start_time"])
        end = datetime.fromisoformat(data["end_time"])
        room_id = int(data["room_id"])
    except (KeyError, ValueError, TypeError):
        return jsonify({"error": "room_id, start_time, end_time required"}), 400

    existing = Event.query.filter(Event.room_id == room_id).all()
    conflicts = ConflictDetector.find_conflicts(start, end, existing)
    return jsonify(
        {
            "has_conflict": bool(conflicts),
            "conflicts": [c.to_dict() for c in conflicts],
            "suggestions": [
                {"start_time": s.isoformat(), "end_time": e.isoformat()}
                for s, e in ConflictDetector.suggest_alternatives(
                    start, end, existing
                )
            ],
        }
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _validate_event_payload(data):
    required = ["title", "organizer_name", "organizer_email",
                "room_id", "start_time", "end_time"]
    for field in required:
        if not data.get(field):
            return f"Missing required field: {field}"

    try:
        start = datetime.fromisoformat(data["start_time"])
        end = datetime.fromisoformat(data["end_time"])
    except ValueError:
        return "start_time and end_time must be ISO 8601 datetimes"

    if end <= start:
        return "End time must be after start time"
    if not Room.query.get(data["room_id"]):
        return "Unknown room"
    return None


if __name__ == "__main__":
    app.run(debug=True, port=5000)
